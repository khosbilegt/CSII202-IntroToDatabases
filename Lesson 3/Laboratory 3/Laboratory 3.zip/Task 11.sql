SELECT staffNo, fName, IName, position, sex, DOB, salary, branchNo FROM Staff
    WHERE BranchNo = "BOO7" OR position = "Manager"