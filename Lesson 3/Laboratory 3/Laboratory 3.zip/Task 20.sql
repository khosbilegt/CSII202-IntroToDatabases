UPDATE Staff
SET position = "Manager" WHERE staffNo = "SL41"