SELECT staffNo, propertyNo, rent, ownerNo FROM PropertyForRent
    WHERE rooms = 3 AND NOT staffNo = " "