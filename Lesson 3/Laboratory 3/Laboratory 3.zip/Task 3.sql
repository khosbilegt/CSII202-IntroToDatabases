SELECT propertyNo, street, city, postcode, propertyType, rooms, rent, ownerNo, staffNo, branchNo FROM PropertyForRent
    WHERE rooms BETWEEN 3 AND 5