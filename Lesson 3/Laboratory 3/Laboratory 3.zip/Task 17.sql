SELECT ownerNo, branchNo FROM PropertyForRent
    WHERE staffNo = "SG37"
    
   # Date baihgui