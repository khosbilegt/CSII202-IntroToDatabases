SELECT staffNo, fName, IName, position, salary, salary/2 AS Halfsalary FROM Staff
