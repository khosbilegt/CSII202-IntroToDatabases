SELECT clientNo, viewDate FROM Viewing
    WHERE comments = "no dining room"