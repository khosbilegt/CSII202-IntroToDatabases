SELECT staffNo, fName, IName, position, sex, DOB, salary, BranchNo FROM Staff
    WHERE position = "Manager"