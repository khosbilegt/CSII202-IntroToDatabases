SELECT staffNo, fName, IName, position, sex, DOB, salary, BranchNo FROM Staff
    WHERE salary > 20000