SELECT clientNo, propertyNo, viewDate, comments FROM Viewing
    WHERE viewDate BETWEEN "2004-05-01" AND "2004-05-31"