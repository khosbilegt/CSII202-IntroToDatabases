# Task 2 must have been completed.

SELECT staffNo, fName, IName, position, sex, DOB, salary, branchNo FROM Staff
    WHERE salary > 15000