# Task 4 must have worked.
DELETE FROM PropertyForRent WHERE rooms = 5