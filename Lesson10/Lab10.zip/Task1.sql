SELECT h.city, h.hotelName, r.roomNo, r.price FROM Hotel h, Room r

WHERE h.hotelNo = r.hotelNo