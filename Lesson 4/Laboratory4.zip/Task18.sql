SELECT clientLastName, phoneNo FROM DatabaseX
# Ийм database байгаа юм уу?

WHERE clientLastName LIKE "%e";