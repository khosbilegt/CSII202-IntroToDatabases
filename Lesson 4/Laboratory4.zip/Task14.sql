SELECT propertyNo, street, city, postcode, propertyType, rooms, rent, ownerNo, staffNo, branchNo FROM PropertyForRent

WHERE rooms = 4 AND rent > 400 AND NOT staffNo = " ";