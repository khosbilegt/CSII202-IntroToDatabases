SELECT SUM(rent) AS sum, MAX(rent) AS maximum FROM PropertyForRent

WHERE propertyType = "Flat";