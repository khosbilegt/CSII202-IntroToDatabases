SELECT fName, position FROM Staff

WHERE branchNo = "B003" OR branchNo = "B005";