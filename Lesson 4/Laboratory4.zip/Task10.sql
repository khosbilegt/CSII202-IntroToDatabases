SELECT propertyNo, street, city, postcode, propertyType, rooms, rent, ownerNo, staffNo, branchNo FROM PropertyForRent

WHERE propertyNo LIKE "%6";