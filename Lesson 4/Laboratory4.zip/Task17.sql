SELECT clientNo, propertyNo, viewDate, comments FROM Viewing

WHERE viewDate LIKE "2003%";