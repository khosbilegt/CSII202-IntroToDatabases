SELECT info, phoneNo FROM DatabaseX
# Ийм database байгаа юм уу?

WHERE phoneNo LIKE "%8%8%8%";