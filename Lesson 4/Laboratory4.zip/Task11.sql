SELECT propertyNo, postcode FROM PropertyForRent

WHERE street = "16 Argyll St";