SELECT staffNo, propertyNo, rent FROM PropertyForRent

WHERE rooms = 3 ORDER BY branchNo, rooms;