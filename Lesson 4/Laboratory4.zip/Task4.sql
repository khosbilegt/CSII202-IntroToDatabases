SELECT info FROM database1

WHERE phoneNo LIKE "%1%1%";