SELECT staffNo, fName, IName, DOB FROM Staff

ORDER BY DOB DESC;