SELECT staffNo, fName, IName, position, sex, DOB, salary, branchNo FROM Staff

WHERE IName LIKE "b%"