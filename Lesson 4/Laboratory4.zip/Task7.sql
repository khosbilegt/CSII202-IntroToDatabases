SELECT MAX(salary) AS maximum, MIN(salary) AS minimum, AVG(ALL salary) AS average FROM Staff

WHERE BranchNo = "B003";