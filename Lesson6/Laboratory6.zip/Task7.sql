CREATE TABLE Rent
  AS (SELECT * FROM PropertyForRent);