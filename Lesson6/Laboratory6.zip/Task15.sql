UPDATE Staff
SET position = "Manager", salary = 25000
WHERE branchNo = "B007" AND sex = "F"