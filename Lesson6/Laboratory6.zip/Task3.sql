SELECT c.* FROM CLIENT c, Viewing v

WHERE v.clientNo = c.clientNo AND viewDate = "2004-01-02"