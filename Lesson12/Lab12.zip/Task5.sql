UPDATE PropertyForRent p

SET rent = rent * 1.15