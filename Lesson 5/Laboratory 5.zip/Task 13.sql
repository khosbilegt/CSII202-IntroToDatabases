SELECT branchNo, COUNT(*) AS Staff, sum(salary) FROM Staff

GROUP BY branchNo;