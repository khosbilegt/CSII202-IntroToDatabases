SELECT COUNT(*) AS branches, city FROM Branch

GROUP BY city;