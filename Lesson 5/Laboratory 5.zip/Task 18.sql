SELECT p.* FROM PropertyForRent p, privateOwner pr

WHERE rent > (fName = "Carol" AND p.ownerNo = pr.ownerNo) AND p.ownerNo = pr.ownerNo