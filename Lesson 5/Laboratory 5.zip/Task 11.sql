SELECT * FROM Staff

ORDER BY branchNo;

SELECT avg(salary), position FROM Staff

GROUP BY position;