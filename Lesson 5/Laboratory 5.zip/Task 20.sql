SELECT p.* FROM PropertyForRent p, privateOwner pr

WHERE rent < (fName = "Tony" AND p.ownerNo = pr.ownerNo) AND p.ownerNo = pr.ownerNo