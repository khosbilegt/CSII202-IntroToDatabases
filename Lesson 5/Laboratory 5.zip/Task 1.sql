SELECT fName, position, salary FROM Staff s, Branch b

WHERE s.branchNo = b.branchNo AND city = "London"