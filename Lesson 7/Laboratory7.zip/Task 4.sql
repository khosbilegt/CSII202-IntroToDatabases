SELECT b.*, p.* FROM PropertyForRent p, Branch b

WHERE b.city = p.city