SELECT PropertyForRent.*, Branch.* FROM PropertyForRent LEFT JOIN Branch

ON PropertyForRent.city = Branch.city

# Left Join zuunees ehelj ON commandiig heregjuulne, nuguu ni baruunaas ehelne.